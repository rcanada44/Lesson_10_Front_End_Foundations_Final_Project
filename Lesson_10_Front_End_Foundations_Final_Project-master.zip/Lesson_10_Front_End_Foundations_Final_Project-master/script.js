


function loadDoc(url, callback) {
    const xhttp = new XMLHttpRequest(); 
        xttp.onereadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("example").innerHTML = this.response.Text;
            }  
        };
        xhttp.open("GET", "https://api.github.com/users/rcanada44/repos", true);
        xhttp.send();    
}

function showRepositories(event, data) {
    var repos = JSON.parse(this.responseText)
    console.log(repos)
    const repoList = `<ul>${repos.map(r => '<li>' + r.name + '</li>').join('')}</ul>`
    document.getElementById("repoList").innerHTML = repoList;
  }
  
  function getRepositories() {
    const req = new XMLHttpRequest()
    req.addEventListener("load", showRepositories);
    req.open("GET", 'https://api.github.com/users/rcanada44/repos')
    req.send()
  }


  
  
   
$(document).ready(function(){

    $("img").hover(function(){
 
        $(this).css("transform", "scale(1.5)");
 
        }, function(){
 
        $(this).css("transform", "scale(1)");
 
    });
 
 });


$(document).ready(function(){
 $("img").hover(function(){
     $(this).css("background-color", "black");
 }, function(){
     $(this).css("background-color", "blue");
 });

});



